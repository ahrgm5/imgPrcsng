/* transforms.c */
#include "transforms.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* =========================================================
 * INTERNAL HELPERS
 * ========================================================= */

static float clampf(float v, float lo, float hi) {
    return (v < lo) ? lo : (v > hi) ? hi : v;
}

static double clampd(double v, double lo, double hi) {
    return (v < lo) ? lo : (v > hi) ? hi : v;
}

static int clampi(int v, int lo, int hi) {
    return (v < lo) ? lo : (v > hi) ? hi : v;
}

/*
 * get_freq_dist — radial distance from the DC origin.
 *
 * DFT: DC is split across the four corners; distance is measured
 *      from the nearest corner.
 * DCT: DC is strictly at (0,0) top-left.
 */
static double get_freq_dist(int i, int j, int h, int w, FilterDomain domain) {
    double di, dj;
    if (domain == FILTER_DOMAIN_DFT) {
        di = (i > h / 2) ? (double)(h - i) : (double)i;
        dj = (j > w / 2) ? (double)(w - j) : (double)j;
    } else {
        di = (double)i;
        dj = (double)j;
    }
    return sqrt(di * di + dj * dj);
}

/* =========================================================
 * SECTION 1 — SPATIAL KERNELS
 * =========================================================
 * Order within section:
 *   1. Kernel* — construction
 *   2. void    — destruction
 *   3. void    — initialisation callbacks
 *   4. BMPImage* — application
 * ========================================================= */

/* ---------------------------------------------------------
 * Kernel construction
 * --------------------------------------------------------- */

Kernel *create_kernel(int w, int h, void (*init_func)(Kernel *), size_t struct_size) {
    Kernel *k;
    int     i;

    k = (Kernel *)malloc(struct_size);
    if (!k) return NULL;
    memset(k, 0, struct_size);

    k->width      = w;
    k->height     = h;
    k->initialize = init_func;

    k->mask = (float **)malloc(h * sizeof(float *));
    if (!k->mask) { free(k); return NULL; }

    for (i = 0; i < h; i++) {
        k->mask[i] = (float *)calloc(w, sizeof(float));
        if (!k->mask[i]) {
            while (--i >= 0) free(k->mask[i]);
            free(k->mask);
            free(k);
            return NULL;
        }
    }

    if (k->initialize) k->initialize(k);
    return k;
}

/* ---------------------------------------------------------
 * Kernel destruction
 * --------------------------------------------------------- */

void destroy_kernel(Kernel *k) {
    int i;
    if (!k) return;
    for (i = 0; i < k->height; i++) free(k->mask[i]);
    free(k->mask);
    free(k);
}

/* ---------------------------------------------------------
 * Kernel initialisation callbacks
 * --------------------------------------------------------- */

void motion_blur_init(Kernel *self) {
    MotionBlurKernel *mbk = (MotionBlurKernel *)self;
    int    L, cx, cy, j;
    double rad, cos_t, sin_t, offset;
    float  scale;
    int    px, py;

    L = mbk->L;
    if (L <= 1) return;

    rad   = mbk->theta * M_PI / 180.0;
    cos_t = cos(rad);
    sin_t = sin(rad);
    scale = 1.0f / (float)L;
    cy    = self->height / 2;
    cx    = self->width  / 2;

    for (j = 0; j < L; j++) {
        offset = (double)j - (L / 2.0);
        px     = (int)round(cx + offset * cos_t);
        py     = (int)round(cy + offset * sin_t);

        if (px >= 0 && px < self->width && py >= 0 && py < self->height) {
            self->mask[py][px] = scale;
        }
    }
}

void average_init(Kernel *self) {
    float val;
    int   i, j;

    val = 1.0f / (float)(self->width * self->height);
    for (i = 0; i < self->height; i++)
        for (j = 0; j < self->width; j++)
            self->mask[i][j] = val;
}

void laplacian_init(Kernel *self) {
    int   cy, cx, i, j;

    if (self->width == 3 && self->height == 3) {
        float lap[3][3] = {
            {-1.0f, -1.0f, -1.0f},
            {-1.0f,  8.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f}
        };
        for (i = 0; i < 3; i++)
            for (j = 0; j < 3; j++)
                self->mask[i][j] = lap[i][j];
    } else {
        cy = self->height / 2;
        cx = self->width  / 2;
        for (i = 0; i < self->height; i++)
            for (j = 0; j < self->width; j++)
                self->mask[i][j] = -1.0f;
        self->mask[cy][cx] = (float)(self->width * self->height - 1);
    }
}

void gaussian_init(Kernel *self) {
    GaussianKernel *gk = (GaussianKernel *)self;
    double          s, sum;
    int             cy, cx, i, j, y, x;

    s   = (gk->sigma <= 0.0) ? 1.0 : gk->sigma;
    sum = 0.0;
    cy  = self->height / 2;
    cx  = self->width  / 2;

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            y = i - cy;
            x = j - cx;
            self->mask[i][j] = (float)(
                exp(-(x * x + y * y) / (2.0 * s * s))
                / (2.0 * M_PI * s * s));
            sum += self->mask[i][j];
        }
    }

    for (i = 0; i < self->height; i++)
        for (j = 0; j < self->width; j++)
            self->mask[i][j] /= (float)sum;
}

void sobel_init(Kernel *self) {
    SobelKernel *sk = (SobelKernel *)self;
    int          i, j;

    if (sk->horizontal) {
        float h_sobel[3][3] = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
        for (i = 0; i < 3; i++)
            for (j = 0; j < 3; j++)
                self->mask[i][j] = h_sobel[i][j];
    } else {
        float v_sobel[3][3] = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};
        for (i = 0; i < 3; i++)
            for (j = 0; j < 3; j++)
                self->mask[i][j] = v_sobel[i][j];
    }
}

/* ---------------------------------------------------------
 * Kernel application
 * --------------------------------------------------------- */

static float convolve(int x, int y, int w, int h,
                      float **buffer, Kernel *k) {
    float sum;
    int   dy, dx, i, j, py, px;

    sum = 0.0f;
    dy  = k->height / 2;
    dx  = k->width  / 2;

    for (i = 0; i < k->height; i++) {
        for (j = 0; j < k->width; j++) {
            py   = clampi(y + i - dy, 0, h - 1);
            px   = clampi(x + j - dx, 0, w - 1);
            sum += buffer[py][px] * k->mask[i][j];
        }
    }
    return sum;
}

BMPImage *apply_kernel_to_bmp(BMPImage *input, Kernel *k) {
    int       w, h, i, j;
    BMPImage *output;
    float   **intensity;
    float   **result;
    HSIImage *hsi;

    w      = input->info_header.width_px;
    h      = abs(input->info_header.height_px);
    output = createEmptyBMP(w, h, input->info_header.bits_per_pixel);
    if (!output) return NULL;

    intensity = (float **)malloc(h * sizeof(float *));
    result    = (float **)malloc(h * sizeof(float *));
    for (i = 0; i < h; i++) {
        intensity[i] = (float *)malloc(w * sizeof(float));
        result[i]    = (float *)malloc(w * sizeof(float));
    }

    hsi = NULL;
    if (input->info_header.bits_per_pixel == 24) {
        hsi = convert_bmp_to_hsi(input);
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                intensity[i][j] = hsi->pixels[i][j].i;
    } else {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                intensity[i][j] = input->pixels[i][j] / 255.0f;
    }

    for (i = 0; i < h; i++)
        for (j = 0; j < w; j++)
            result[i][j] = convolve(j, i, w, h, intensity, k);

    if (hsi) {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                hsi->pixels[i][j].i = clampf(result[i][j], 0.0f, 1.0f);
        update_bmp_from_hsi(output, hsi);
        freeHSIImage(hsi);
    } else {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                output->pixels[i][j] =
                    (uint8_t)clampf(result[i][j] * 255.0f, 0.0f, 255.0f);
    }

    for (i = 0; i < h; i++) { free(intensity[i]); free(result[i]); }
    free(intensity);
    free(result);

    return output;
}


/* =========================================================
 * SECTION 2 — FREQUENCY-DOMAIN FILTERS
 * =========================================================
 * Order within section:
 *   1. Filter*   — construction (generic then specialised)
 *   2. void      — destruction
 *   3. void      — mask (filter logic) callbacks
 *   4. void      — filter execution
 *   5. BMPImage* — filter application
 * ========================================================= */

/* ---------------------------------------------------------
 * Filter construction
 * --------------------------------------------------------- */

Filter *create_filter(FilterDomain domain, int w, int h,
                      void (*mask_func)(Filter *), size_t struct_size) {
    Filter *f;
    int     i;

    f = (Filter *)calloc(1, struct_size);
    if (!f) return NULL;

    f->domain      = domain;
    f->width       = w;
    f->height      = h;
    f->apply_mask  = mask_func;

    f->img_in  = (double **)malloc(h * sizeof(double *));
    f->img_out = (double **)malloc(h * sizeof(double *));
    for (i = 0; i < h; i++) {
        f->img_in[i]  = (double *)calloc(w, sizeof(double));
        f->img_out[i] = (double *)calloc(w, sizeof(double));
    }

    if (domain == FILTER_DOMAIN_DFT) {
        f->dft_in      = fftw_alloc_complex(w * h);
        f->dft_out     = fftw_alloc_complex(w * h);
        f->dft_forward = fftw_plan_dft_2d(h, w,
                             f->dft_in, f->dft_out,
                             FFTW_FORWARD,  FFTW_ESTIMATE);
        f->dft_backward = fftw_plan_dft_2d(h, w,
                              f->dft_out, f->dft_in,
                              FFTW_BACKWARD, FFTW_ESTIMATE);
    } else {
        f->dct_in  = (double *)fftw_malloc(sizeof(double) * w * h);
        f->dct_out = (double *)fftw_malloc(sizeof(double) * w * h);
        f->dct_forward  = fftw_plan_r2r_2d(h, w,
                               f->dct_in,  f->dct_out,
                               FFTW_REDFT10, FFTW_REDFT10, FFTW_ESTIMATE);
        f->dct_backward = fftw_plan_r2r_2d(h, w,
                               f->dct_out, f->dct_in,
                               FFTW_REDFT01, FFTW_REDFT01, FFTW_ESTIMATE);
    }
    return f;
}

Filter *create_wiener_filter(FilterDomain domain, int w, int h,
                             Kernel *blur_kernel, double K) {
    Filter       *f;
    WienerFilter *wf;
    fftw_complex *kernel_spatial;
    fftw_plan     p;
    int           kh, kw, i, j, ni, nj;

    if (domain != FILTER_DOMAIN_DFT) {
        printf("Error: Wiener filter requires FILTER_DOMAIN_DFT.\n");
        return NULL;
    }

    f = create_filter(domain, w, h, wiener_filter_logic, sizeof(WienerFilter));
    if (!f) return NULL;

    wf    = (WienerFilter *)f;
    wf->K = K;
    wf->H = fftw_alloc_complex(w * h);

    /* Build a zero-padded spatial buffer for the kernel centred to
       avoid phase shifts after the forward DFT. */
    kernel_spatial = fftw_alloc_complex(w * h);
    for (i = 0; i < h * w; i++) {
        kernel_spatial[i][0] = 0.0;
        kernel_spatial[i][1] = 0.0;
    }

    kh = blur_kernel->height;
    kw = blur_kernel->width;
    for (i = 0; i < kh; i++) {
        for (j = 0; j < kw; j++) {
            ni = (i - kh / 2 + h) % h;
            nj = (j - kw / 2 + w) % w;
            kernel_spatial[ni * w + nj][0] = blur_kernel->mask[i][j];
        }
    }

    p = fftw_plan_dft_2d(h, w, kernel_spatial, wf->H,
                         FFTW_FORWARD, FFTW_ESTIMATE);
    fftw_execute(p);
    fftw_destroy_plan(p);
    fftw_free(kernel_spatial);

    return f;
}

/* ---------------------------------------------------------
 * Filter destruction
 * --------------------------------------------------------- */

void destroy_filter(Filter *f) {
    int i;

    if (!f) return;

    for (i = 0; i < f->height; i++) {
        free(f->img_in[i]);
        free(f->img_out[i]);
    }
    free(f->img_in);
    free(f->img_out);

    if (f->domain == FILTER_DOMAIN_DFT) {
        fftw_destroy_plan(f->dft_forward);
        fftw_destroy_plan(f->dft_backward);
        fftw_free(f->dft_in);
        fftw_free(f->dft_out);
    } else {
        fftw_destroy_plan(f->dct_forward);
        fftw_destroy_plan(f->dct_backward);
        fftw_free(f->dct_in);
        fftw_free(f->dct_out);
    }
    free(f);
}

void destroy_wiener_filter(Filter *f) {
    WienerFilter *wf;
    if (!f) return;
    wf = (WienerFilter *)f;
    if (wf->H) fftw_free(wf->H);
    destroy_filter(f);
}

/* ---------------------------------------------------------
 * Mask (filter logic) callbacks
 * --------------------------------------------------------- */

void wiener_filter_logic(Filter *self) {
    WienerFilter *wf;
    int           N, i;
    double        K, a, b, den, g_r, g_i;
    fftw_complex *G;

    wf = (WienerFilter *)self;
    N  = self->width * self->height;
    K  = wf->K;
    G  = self->dft_out;

    for (i = 0; i < N; i++) {
        a   = wf->H[i][0];
        b   = wf->H[i][1];
        den = (a * a + b * b) + K;   /* |H|^2 + K */
        g_r = G[i][0];
        g_i = G[i][1];

        /* F'(u,v) = G(u,v) * H*(u,v) / den */
        G[i][0] = (g_r * a + g_i * b) / den;
        G[i][1] = (g_i * a - g_r * b) / den;
    }
}

void rect_truncation_logic(Filter *self) {
    TruncationFilter *tf;
    double            ratio;
    int               limit_h, limit_w, i, j, di, dj;
    int               mask_out;

    tf      = (TruncationFilter *)self;
    ratio   = sqrt(tf->percent);
    limit_h = (int)(self->height * ratio / 2.0);
    limit_w = (int)(self->width  * ratio / 2.0);

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            mask_out = 0;

            if (self->domain == FILTER_DOMAIN_DFT) {
                di = (i > self->height / 2) ? (self->height - i) : i;
                dj = (j > self->width  / 2) ? (self->width  - j) : j;
                if (di > limit_h || dj > limit_w) mask_out = 1;
            } else {
                if (i > limit_h * 2 || j > limit_w * 2) mask_out = 1;
            }

            if (mask_out) {
                if (self->domain == FILTER_DOMAIN_DFT) {
                    self->dft_out[i * self->width + j][0] = 0.0;
                    self->dft_out[i * self->width + j][1] = 0.0;
                } else {
                    self->dct_out[i * self->width + j] = 0.0;
                }
            }
        }
    }
}

void lpf_logic(Filter *self) {
    double cutoff;
    int    i, j;

    cutoff = ((LpFilter *)self)->cutoff;

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            if (get_freq_dist(i, j, self->height, self->width,
                              self->domain) > cutoff) {
                if (self->domain == FILTER_DOMAIN_DFT) {
                    self->dft_out[i * self->width + j][0] = 0.0;
                    self->dft_out[i * self->width + j][1] = 0.0;
                } else {
                    self->dct_out[i * self->width + j] = 0.0;
                }
            }
        }
    }
}

void hpf_logic(Filter *self) {
    double cutoff;
    int    i, j;

    cutoff = ((HpFilter *)self)->cutoff;

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            if (get_freq_dist(i, j, self->height, self->width,
                              self->domain) <= cutoff) {
                if (self->domain == FILTER_DOMAIN_DFT) {
                    self->dft_out[i * self->width + j][0] = 0.0;
                    self->dft_out[i * self->width + j][1] = 0.0;
                } else {
                    self->dct_out[i * self->width + j] = 0.0;
                }
            }
        }
    }
}

void bpf_logic(Filter *self) {
    double low, high, d;
    int    i, j;

    low  = ((BpFilter *)self)->low;
    high = ((BpFilter *)self)->high;

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            d = get_freq_dist(i, j, self->height, self->width, self->domain);
            if (d < low || d > high) {
                if (self->domain == FILTER_DOMAIN_DFT) {
                    self->dft_out[i * self->width + j][0] = 0.0;
                    self->dft_out[i * self->width + j][1] = 0.0;
                } else {
                    self->dct_out[i * self->width + j] = 0.0;
                }
            }
        }
    }
}

void brf_logic(Filter *self) {
    double low, high, d;
    int    i, j;

    low  = ((BrFilter *)self)->low;
    high = ((BrFilter *)self)->high;

    for (i = 0; i < self->height; i++) {
        for (j = 0; j < self->width; j++) {
            d = get_freq_dist(i, j, self->height, self->width, self->domain);
            if (d >= low && d <= high) {
                if (self->domain == FILTER_DOMAIN_DFT) {
                    self->dft_out[i * self->width + j][0] = 0.0;
                    self->dft_out[i * self->width + j][1] = 0.0;
                } else {
                    self->dct_out[i * self->width + j] = 0.0;
                }
            }
        }
    }
}

/* ---------------------------------------------------------
 * Filter execution
 * --------------------------------------------------------- */

void filter_execute(Filter *f) {
    int    w, h, i, j;
    double norm;

    w = f->width;
    h = f->height;

    if (f->domain == FILTER_DOMAIN_DFT) {
        /* 1. Load spatial data into complex input buffer */
        for (i = 0; i < h; i++) {
            for (j = 0; j < w; j++) {
                f->dft_in[i * w + j][0] = f->img_in[i][j];
                f->dft_in[i * w + j][1] = 0.0;
            }
        }

        /* 2. Forward transform  (spatial -> frequency) */
        fftw_execute(f->dft_forward);

        /* 3. Apply frequency-domain mask */
        if (f->apply_mask) f->apply_mask(f);

        /* 4. Inverse transform (frequency -> spatial) */
        fftw_execute(f->dft_backward);

        /* 5. Normalise and extract */
        norm = 1.0 / (w * h);
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                f->img_out[i][j] = f->dft_in[i * w + j][0] * norm;

    } else {
        /* 1. Load spatial data into real input buffer */
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                f->dct_in[i * w + j] = f->img_in[i][j];

        /* 2. Forward transform (spatial -> frequency) */
        fftw_execute(f->dct_forward);

        /* 3. Apply frequency-domain mask */
        if (f->apply_mask) f->apply_mask(f);

        /* 4. Inverse transform (frequency -> spatial) */
        fftw_execute(f->dct_backward);

        /* 5. Normalise and extract  (DCT-II/IDCT-II scaling: 1/(4N)) */
        norm = 1.0 / (4.0 * w * h);
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                f->img_out[i][j] = f->dct_in[i * w + j] * norm;
    }
}

/* ---------------------------------------------------------
 * Filter application
 * --------------------------------------------------------- */

BMPImage *apply_frequency_filter_to_bmp(BMPImage *input, Filter *f) {
    int       w, h, i, j;
    BMPImage *output;
    HSIImage *hsi;

    w = input->info_header.width_px;
    h = abs(input->info_header.height_px);

    if (w != f->width || h != f->height) return NULL;

    output = createEmptyBMP(w, h, input->info_header.bits_per_pixel);
    if (!output) return NULL;

    hsi = NULL;

    /* Load image data into filter input buffer */
    if (input->info_header.bits_per_pixel == 24) {
        hsi = convert_bmp_to_hsi(input);
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                f->img_in[i][j] = hsi->pixels[i][j].i;
    } else {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                f->img_in[i][j] = input->pixels[i][j] / 255.0;
    }

    /* Forward transform -> mask -> inverse transform */
    filter_execute(f);

    /* Extract results back into the output image */
    if (hsi) {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                hsi->pixels[i][j].i =
                    (float)clampd(f->img_out[i][j], 0.0, 1.0);
        update_bmp_from_hsi(output, hsi);
        freeHSIImage(hsi);
    } else {
        for (i = 0; i < h; i++)
            for (j = 0; j < w; j++)
                output->pixels[i][j] =
                    (uint8_t)clampd(f->img_out[i][j] * 255.0, 0.0, 255.0);
    }

    return output;
}
