/* main.c */
#include "bmp.h"
#include "transforms.h"
#include "imgproc.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* =========================================================
 * HELPER — Gaussian noise
 * ========================================================= */

/*
 * add_gaussian_noise
 *
 * Adds zero-mean Gaussian noise with the given variance (in normalised
 * 0-1 units) to every pixel.  Uses the Box-Muller transform to produce
 * normally-distributed samples without relying on C++ <random>.
 */
static void add_gaussian_noise(BMPImage *img, double variance) {
    double std_dev, u1, u2, z, noise;
    int    w, h, i, j, c, val;

    std_dev = sqrt(variance);
    w       = img->info_header.width_px;
    h       = abs(img->info_header.height_px);

    for (i = 0; i < h; i++) {
        for (j = 0; j < w; j++) {
            if (img->info_header.bits_per_pixel == 24) {
                for (c = 0; c < 3; c++) {
                    /* Box-Muller */
                    do { u1 = (double)rand() / RAND_MAX; } while (u1 == 0.0);
                    u2   = (double)rand() / RAND_MAX;
                    z    = sqrt(-2.0 * log(u1)) * cos(2.0 * 3.14159265358979 * u2);
                    noise = z * std_dev * 255.0;
                    val   = (int)img->pixels[i][j * 3 + c] + (int)noise;
                    if (val < 0)   val = 0;
                    if (val > 255) val = 255;
                    img->pixels[i][j * 3 + c] = (unsigned char)val;
                }
            } else {
                do { u1 = (double)rand() / RAND_MAX; } while (u1 == 0.0);
                u2    = (double)rand() / RAND_MAX;
                z     = sqrt(-2.0 * log(u1)) * cos(2.0 * 3.14159265358979 * u2);
                noise = z * std_dev * 255.0;
                val   = (int)img->pixels[i][j] + (int)noise;
                if (val < 0)   val = 0;
                if (val > 255) val = 255;
                img->pixels[i][j] = (unsigned char)val;
            }
        }
    }
}

/* =========================================================
 * HELPER — path concatenation
 * ========================================================= */

static void build_path(char *out, size_t out_size,
                       const char *base, const char *rel) {
    snprintf(out, out_size, "%s%s", base, rel);
}

/* =========================================================
 * MAIN
 * ========================================================= */

int main(void) {
    const char *src_images = "/home/ahrgm/Projects/imgPrcsng/Course/images/";
    const char *save_path  = "/home/ahrgm/Projects/imgPrcsng/Course/HW/HW3/";

    char path_buf[512];

    /* =========================================================
     * Problem 1.1 — Known degradation and Wiener restoration
     * ========================================================= */
    {
        BMPImage         *building, *blurred, *restored;
        MotionBlurKernel *mbk;
        Filter           *wf;
        int               w, h;

        build_path(path_buf, sizeof(path_buf), src_images, "building.bmp");
        building = readBMP(path_buf);

        if (building) {
            w = building->info_header.width_px;
            h = abs(building->info_header.height_px);

            /* (a) Degrade: 7-pixel motion blur at 45 degrees + noise */
            mbk       = (MotionBlurKernel *)create_kernel(
                             31, 31, NULL, sizeof(MotionBlurKernel));
            mbk->L     = 7;
            mbk->theta = 45.0;
            motion_blur_init((Kernel *)mbk);

            blurred = apply_kernel_to_bmp(building, (Kernel *)mbk);
            add_gaussian_noise(blurred, 0.01);

            build_path(path_buf, sizeof(path_buf),
                       save_path, "Problem1/1.1/degraded.bmp");
            writeBMP(path_buf, blurred);

            /* (b) Restore with Wiener filter */
            wf       = create_wiener_filter(FILTER_DOMAIN_DFT, w, h,
                                            (Kernel *)mbk, 0.01);
            restored = apply_frequency_filter_to_bmp(blurred, wf);

            build_path(path_buf, sizeof(path_buf),
                       save_path, "Problem1/1.1/restored.bmp");
            writeBMP(path_buf, restored);

            destroy_wiener_filter(wf);
            destroy_kernel((Kernel *)mbk);
            freeBMPImage(building);
            freeBMPImage(blurred);
            freeBMPImage(restored);
        }
    }

    /* =========================================================
     * Problem 1.2 — Parameter search for urbanblur.bmp
     * ========================================================= */
    {
        BMPImage         *img_blur, *img_real, *res, *best_img;
        MotionBlurKernel *mbk;
        Kernel           *base_k;
        Filter           *f;
        int               w, h, li, ai, ki, y, x;
        double            mse, min_mse;
        int               best_L;
        double            best_theta, best_K;

        static const int    blur_lengths[] = {1, 3, 5, 7, 9};
        static const double blur_angles[]  = {0.0, 45.0, 90.0, 135.0, 180.0};
        static const double K_factors[]    = {0.001, 0.01, 0.1, 1.0};

        build_path(path_buf, sizeof(path_buf), src_images, "urbanblur.bmp");
        img_blur = readBMP(path_buf);

        build_path(path_buf, sizeof(path_buf), src_images, "urban0.bmp");
        img_real = readBMP(path_buf);

        if (!img_blur || !img_real) return -1;

        w = img_blur->info_header.width_px;
        h = abs(img_blur->info_header.height_px);

        mbk    = (MotionBlurKernel *)create_kernel(
                      31, 31, NULL, sizeof(MotionBlurKernel));
        base_k = (Kernel *)mbk;

        min_mse    = 1e9;
        best_L     = 0;
        best_theta = 0.0;
        best_K     = 0.0;
        best_img   = NULL;

        for (li = 0; li < 5; li++) {
            for (ai = 0; ai < 5; ai++) {
                /* Reset kernel mask */
                for (y = 0; y < base_k->height; y++)
                    for (x = 0; x < base_k->width; x++)
                        base_k->mask[y][x] = 0.0f;

                mbk->L     = blur_lengths[li];
                mbk->theta = blur_angles[ai];
                motion_blur_init(base_k);

                for (ki = 0; ki < 4; ki++) {
                    f   = create_wiener_filter(FILTER_DOMAIN_DFT, w, h,
                                               base_k, K_factors[ki]);
                    res = apply_frequency_filter_to_bmp(img_blur, f);

                    if (res) {
                        mse = calculate_mse(img_real, res);
                        if (mse < min_mse) {
                            min_mse    = mse;
                            best_L     = blur_lengths[li];
                            best_theta = blur_angles[ai];
                            best_K     = K_factors[ki];
                            if (best_img) freeBMPImage(best_img);
                            best_img = res;
                        } else {
                            freeBMPImage(res);
                        }
                    }
                    destroy_wiener_filter(f);
                }
            }
        }

        printf("1.2 Best Result: L=%d  Theta=%.1f  K=%.4f  MSE=%.4f\n",
               best_L, best_theta, best_K, min_mse);

        if (best_img) {
            build_path(path_buf, sizeof(path_buf),
                       save_path, "Problem1/1.2/best_restoration.bmp");
            writeBMP(path_buf, best_img);
            freeBMPImage(best_img);
        }

        destroy_kernel(base_k);
        freeBMPImage(img_blur);
        freeBMPImage(img_real);
    }

    /* =========================================================
     * Problem 2 — HSI colour segmentation
     * ========================================================= */
    {
        BMPImage  *color_img;
        BMPImages  results;
        int        i;

        static const char *names[]       = {"red", "yellow", "green",
                                            "blue", "purple"};
        static const float target_hues[] = {0.0f, 30.0f, 120.0f,
                                            220.0f, 300.0f};
        static const int   n_hues        = 5;
        const float        hue_tol       = 15.0f;
        const float        min_sat       = 0.2f;

        build_path(path_buf, sizeof(path_buf), src_images, "color_image.bmp");
        color_img = readBMP(path_buf);

        if (color_img) {
            results = segment_color_hsi(color_img, target_hues, n_hues,
                                        hue_tol, min_sat);

            for (i = 0; i < results.count; i++) {
                char rel[64];
                snprintf(rel, sizeof(rel), "%s.bmp", names[i]);
                build_path(path_buf, sizeof(path_buf), save_path, rel);
                writeBMP(path_buf, results.images[i]);
            }

            freeBMPImages(results);
            freeBMPImage(color_img);
        }
    }

    return 0;
}
