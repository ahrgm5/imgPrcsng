#ifndef TRANSFORMS_H
#define TRANSFORMS_H

#include "bmp.h"
#include <fftw3.h>
#include <stddef.h>

/* =========================================================
 * SECTION 1 — SPATIAL KERNELS
 * =========================================================
 * Structs and functions are ordered by return type:
 *   Kernel construction  ->  Kernel*
 *   Kernel destruction   ->  void
 *   Kernel application   ->  BMPImage*
 * ========================================================= */

/* --- Kernel base type ------------------------------------ */

typedef struct Kernel {
    int    width;
    int    height;
    float **mask;
    void (*initialize)(struct Kernel *self);
} Kernel;

/* --- Concrete kernel types (sub-types of Kernel) --------- */

typedef struct {
    Kernel base;
    int    L;       /* Blur length in pixels */
    double theta;   /* Blur angle in degrees */
} MotionBlurKernel;

typedef struct {
    Kernel base;
} AverageKernel;

typedef struct {
    Kernel base;
    float  k;      /* Center scaling factor */
} LaplacianKernel;

typedef struct {
    Kernel base;
    double sigma;  /* Gaussian standard deviation */
} GaussianKernel;

typedef struct {
    Kernel base;
    int    horizontal; /* Non-zero => horizontal Sobel, else vertical */
} SobelKernel;

/* --- Kernel initialisation callbacks --------------------- */

void motion_blur_init(Kernel *self);
void average_init(Kernel *self);
void laplacian_init(Kernel *self);
void gaussian_init(Kernel *self);
void sobel_init(Kernel *self);

/* --- Kernel construction / destruction ------------------- */

Kernel *create_kernel(int w, int h, void (*init_func)(Kernel *), size_t struct_size);
void    destroy_kernel(Kernel *k);

/* --- Kernel application ---------------------------------- */

BMPImage *apply_kernel_to_bmp(BMPImage *input, Kernel *k);


/* =========================================================
 * SECTION 2 — FREQUENCY-DOMAIN FILTERS
 * =========================================================
 * Structs and functions are ordered by return type:
 *   Filter construction  ->  Filter*
 *   Filter destruction   ->  void
 *   Filter execution     ->  void  (modifies Filter in-place)
 *   Filter application   ->  BMPImage*
 * ========================================================= */

/* --- Transform domain selector --------------------------- */

typedef enum {
    FILTER_DOMAIN_DFT,
    FILTER_DOMAIN_DCT
} FilterDomain;

/* --- Filter base type ------------------------------------ */

typedef struct Filter {
    FilterDomain  domain;
    int           width;
    int           height;
    double      **img_in;
    double      **img_out;

    /* DFT buffers and plans (used when domain == FILTER_DOMAIN_DFT) */
    fftw_complex *dft_in;
    fftw_complex *dft_out;
    fftw_plan     dft_forward;
    fftw_plan     dft_backward;

    /* DCT buffers and plans (used when domain == FILTER_DOMAIN_DCT) */
    double       *dct_in;
    double       *dct_out;
    fftw_plan     dct_forward;
    fftw_plan     dct_backward;

    void (*apply_mask)(struct Filter *self);
} Filter;

/* --- Concrete filter types (sub-types of Filter) --------- */

typedef struct { Filter base; double percent;           } TruncationFilter;
typedef struct { Filter base; double cutoff;            } LpFilter;
typedef struct { Filter base; double cutoff;            } HpFilter;
typedef struct { Filter base; double low;  double high; } BpFilter;
typedef struct { Filter base; double low;  double high; } BrFilter;
typedef struct { Filter base; double sigma;             } GaussianFilter;
typedef struct {
    Filter        base;
    fftw_complex *H;   /* OTF of the blur kernel in frequency domain */
    double        K;   /* Noise-to-signal power ratio                */
} WienerFilter;

/* --- Mask (filter logic) callbacks ----------------------- */

void wiener_filter_logic(Filter *self);
void rect_truncation_logic(Filter *self);
void lpf_logic(Filter *self);
void hpf_logic(Filter *self);
void bpf_logic(Filter *self);
void brf_logic(Filter *self);

/* --- Filter construction / destruction ------------------- */

Filter *create_filter(FilterDomain domain, int w, int h,
                      void (*mask_func)(Filter *), size_t struct_size);

Filter *create_wiener_filter(FilterDomain domain, int w, int h,
                             Kernel *blur_kernel, double K);

void destroy_filter(Filter *f);
void destroy_wiener_filter(Filter *f);

/* --- Filter execution ------------------------------------ */

void filter_execute(Filter *f);

/* --- Filter application ---------------------------------- */

BMPImage *apply_frequency_filter_to_bmp(BMPImage *input, Filter *f);

#endif /* TRANSFORMS_H */
